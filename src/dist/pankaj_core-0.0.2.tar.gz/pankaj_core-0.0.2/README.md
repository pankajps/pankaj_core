# Pankaj_Code

Pankaj_Code is a test example Python package designed for demonstration purposes.

## Installation

You can install Pankaj_Code using pip:

```bash
pip install pankaj_code
